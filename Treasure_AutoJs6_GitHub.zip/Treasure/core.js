/* 纯逻辑模块：无 Android / AutoJs6 依赖，可用 Node.js 做逻辑自测。 */
var STAT_SYNONYMS = {
  "生命值百分比": ["生命值百分比", "生命百分比", "生命值%", "生命%", "生命加成", "血量百分比", "血量%"],
  "近战伤害百分比": ["近战伤害百分比", "近战伤害%", "近战攻击百分比", "近战攻击%"],
  "远程伤害百分比": ["远程伤害百分比", "远程伤害%", "远程攻击百分比", "远程攻击%", "射击伤害百分比"],
  "暴击机会": ["暴击机会", "暴击率", "暴击几率", "暴击概率", "暴击机率"],
  "暴击伤害": ["暴击伤害", "暴击伤害加成", "爆伤"],
  "准备时间": ["准备时间", "装填时间", "冷却时间", "准备时长"],
  "近战伤害": ["近战伤害", "近战攻击", "近战攻击力"],
  "远程伤害": ["远程伤害", "远程攻击", "远程攻击力", "射击伤害"],
  "生命值": ["生命值", "生命", "血量", "生命上限"],
  "敏捷": ["敏捷", "移动速度", "行动速度"],
  "射程": ["射程", "攻击范围", "攻击距离"],
  "成本": ["成本", "费用", "部署成本", "能量成本", "消耗"],
  "勇气": ["勇气", "士气"],
  "魅力": ["魅力", "魅力值"]
};

var PART_SYNONYMS = {
  "杯子": ["杯子", "圣杯", "奖杯", "杯", "trophy", "cup"],
  "刀": ["刀", "匕首", "短刀", "手术刀", "dagger", "knife"],
  "表": ["手表", "腕表", "怀表", "表", "watch"],
  "书": ["塔罗牌书", "塔罗书", "书籍", "书", "tome", "book"]
};

var SET_SYNONYMS = {
  "猎人": ["猎人", "hunter"],
  "军人": ["军人", "soldier"],
  "幸运儿": ["幸运儿", "幸运", "lucky guy", "lucky"],
  "绅士": ["绅士", "gentleman"],
  "健身": ["健身", "fitness"],
  "老大": ["老大", "boss"],
  "瑞士": ["瑞士", "swiss"],
  "外科": ["外科", "surgeon"],
  "职业杀手": ["职业杀手", "hitman"],
  "赌博": ["赌博", "gambling"],
  "消防员": ["消防员", "firefighter"],
  "童子军": ["童子军", "scout"],
  "大男孩": ["大男孩", "big boy"],
  "爱国者": ["爱国者", "patriot"],
  "破冰者": ["破冰者", "ice breaker"],
  "独狼": ["独狼", "lone wolf"],
  "齿轮系": ["齿轮系", "齿轮", "gear"],
  "针垫": ["针垫", "pincushion"],
  "碳纤": ["碳纤", "carbon"],
  "尖刺": ["尖刺", "spikes"],
  "圣物": ["圣物", "relic"]
};

function normalize(value) {
  var s = String(value == null ? "" : value).toLowerCase();
  s = s.replace(/[：:，,。．.、;；\s\t\r\n\-_+＋]/g, "");
  s = s.replace(/[（）()\[\]{}【】]/g, "");
  s = s.replace(/％/g, "%");
  return s;
}

function makeCandidates(canonicalList, synonymMap) {
  var all = [];
  var seen = {};
  (canonicalList || []).forEach(function (canonical) {
    var aliases = [canonical].concat((synonymMap && synonymMap[canonical]) || []);
    aliases.forEach(function (alias) {
      var n = normalize(alias);
      if (!n || seen[n]) return;
      seen[n] = true;
      all.push({ canonical: canonical, alias: n, length: n.length });
    });
  });
  all.sort(function (a, b) {
    if (b.length !== a.length) return b.length - a.length;
    return a.alias.localeCompare(b.alias);
  });
  return all;
}

function matchKeyword(input, canonicalList, synonymMap) {
  var text = normalize(input);
  if (!text) return null;
  var candidates = makeCandidates(canonicalList, synonymMap);
  for (var i = 0; i < candidates.length; i++) {
    if (text.indexOf(candidates[i].alias) >= 0) return candidates[i].canonical;
  }
  return null;
}

function matchStatRow(input, canonicalList, synonymMap) {
  var normalized = normalize(input);
  if (!normalized) return null;

  /* 游戏对比面板可能把“生命值 7%”显示为数值夹在名称与百分号之间；
   * 单纯最长子串匹配会误判成平生命值，因此先根据百分号与词干判百分比词条。 */
  if (normalized.indexOf("%") >= 0) {
    if ((normalized.indexOf("生命值") >= 0 || normalized.indexOf("生命") >= 0) && canonicalList.indexOf("生命值百分比") >= 0) {
      return "生命值百分比";
    }
    if (normalized.indexOf("近战伤害") >= 0 && canonicalList.indexOf("近战伤害百分比") >= 0) {
      return "近战伤害百分比";
    }
    if (normalized.indexOf("远程伤害") >= 0 && canonicalList.indexOf("远程伤害百分比") >= 0) {
      return "远程伤害百分比";
    }
  }
  return matchKeyword(input, canonicalList, synonymMap);
}

function matchAllKeywords(input, canonicalList, synonymMap) {
  var text = normalize(input);
  if (!text) return [];
  var candidates = makeCandidates(canonicalList, synonymMap);
  var hits = [];
  var occupied = [];
  candidates.forEach(function (candidate) {
    var from = 0;
    while (from <= text.length - candidate.alias.length) {
      var pos = text.indexOf(candidate.alias, from);
      if (pos < 0) break;
      var end = pos + candidate.alias.length;
      var overlaps = occupied.some(function (span) { return pos < span.end && end > span.start; });
      if (!overlaps) {
        hits.push({ canonical: candidate.canonical, start: pos, end: end });
        occupied.push({ start: pos, end: end });
        break;
      }
      from = pos + 1;
    }
  });
  hits.sort(function (a, b) { return a.start - b.start; });
  var result = [];
  hits.forEach(function (hit) {
    if (result.indexOf(hit.canonical) < 0) result.push(hit.canonical);
  });
  return result;
}

function parseLevel(input) {
  var s = normalize(input).replace(/等級/g, "等级");
  var m = s.match(/等级(?:别)?(\d{1,2})/);
  if (!m) m = s.match(/lv\.?([0-9]{1,2})/i);
  if (!m) return null;
  var n = parseInt(m[1], 10);
  return isNaN(n) ? null : n;
}

function findSet(input, allowedSets) {
  return matchKeyword(input, allowedSets, SET_SYNONYMS);
}

function inferPartFromMain(mainStat, mainStatsByPart) {
  if (!mainStat) return null;
  var found = [];
  Object.keys(mainStatsByPart).forEach(function (part) {
    if ((mainStatsByPart[part] || []).indexOf(mainStat) >= 0) found.push(part);
  });
  return found.length === 1 ? found[0] : null;
}

function evaluateAffixes(data, cfg) {
  var main = data.mainStat;
  var sub = data.subStats || [];
  var core = cfg.TARGET_CORE_AFFIX;
  var required = cfg.REQUIRED_SUB_STATS || [];

  if (!main) return { ok: false, kind: "uncertain", reason: "主词条为空，不能安全判定" };
  if (core === main) return { ok: false, kind: "conflict", reason: "核心词条与主词条重复：" + main };
  var mainConflict = required.filter(function (s) { return s === main; });
  if (mainConflict.length) {
    return { ok: false, kind: "conflict", reason: "目标副词条与主词条重复：" + main };
  }

  if (sub.indexOf(core) < 0) {
    return { ok: false, kind: "junk", reason: "缺少核心词条：" + core };
  }
  var missing = required.filter(function (s) { return sub.indexOf(s) < 0; });
  if (cfg.REQUIRE_ALL_SUB_STATS !== false && missing.length) {
    return { ok: false, kind: "junk", reason: "缺少目标副词条：" + missing.join("、") };
  }
  if (cfg.REQUIRE_ALL_SUB_STATS === false && required.length && required.every(function (s) { return sub.indexOf(s) < 0; })) {
    return { ok: false, kind: "junk", reason: "没有命中任何一个可选副词条" };
  }
  return { ok: true, kind: "treasure", reason: "核心词条及副词条组合全部满足" };
}

module.exports = {
  STAT_SYNONYMS: STAT_SYNONYMS,
  PART_SYNONYMS: PART_SYNONYMS,
  SET_SYNONYMS: SET_SYNONYMS,
  normalize: normalize,
  matchKeyword: matchKeyword,
  matchStatRow: matchStatRow,
  matchAllKeywords: matchAllKeywords,
  parseLevel: parseLevel,
  findSet: findSet,
  inferPartFromMain: inferPartFromMain,
  evaluateAffixes: evaluateAffixes
};
