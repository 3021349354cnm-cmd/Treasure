"auto";

/*
 * 《死亡突围：僵尸战争》装备自动筛选 / 重置助手
 * Runtime: AutoJs6 6.7.0 (Rhino)；OCR: 内置 Rapid OCR 模式（中文文本）。
 * 本脚本只通过截图、固定区域裁剪、OCR、像素采样和无障碍 gesture 坐标手势操作。
 * 不读取 Android 控件树或控件选择器。
 */

var CONFIG = require("./config.js");
var Core = require("./core.js");

var STATES = {
  SCAN_BAG: "STATE_SCAN_BAG",
  READ_DETAIL: "STATE_READ_DETAIL",
  JUDGE_CONFLICT: "STATE_JUDGE_CONFLICT",
  JUDGE_RULES: "STATE_JUDGE_RULES",
  CLICK_RESET: "STATE_CLICK_RESET",
  WAIT_RESET_COOLDOWN: "STATE_WAIT_RESET_COOLDOWN",
  JUDGE_RESULT: "STATE_JUDGE_RESULT",
  CLICK_REROLL: "STATE_CLICK_REROLL",
  WAIT_REROLL_COOLDOWN: "STATE_WAIT_REROLL_COOLDOWN",
  CLICK_CONTINUE: "STATE_CLICK_CONTINUE",
  WAIT_CONTINUE: "STATE_WAIT_CONTINUE",
  NEXT_ITEM: "STATE_NEXT_ITEM",
  PAUSE: "STATE_PAUSE",
  STOP: "STATE_STOP"
};

var runtime = {
  state: STATES.SCAN_BAG,
  bagCursor: 0,
  currentSlot: null,
  currentItem: null,
  currentRerolls: 0,
  totalRerolls: 0,
  visitedCells: {},
  successItems: [],
  junkReasons: {},
  ocrBadStreak: 0,
  structuralBadStreak: 0,
  lastGestureAt: 0,
  lastResetAt: 0,
  lastRerollAt: 0,
  rerollLock: false,
  beforeRerollSignature: "",
  coinBalanceBeforeReroll: null,
  compareSnapshot: null,
  pauseReason: "",
  stopReason: "",
  lastFullOcr: null,
  lastFullImage: null,
  lastOcrError: "",
  resetButtonPoint: null
};

var SUB_STATS = CONFIG.SUB_STATS;
var PARTS = Object.keys(CONFIG.EQUIPMENT_MAIN_STATS);
var FULL_SCREEN = { left: 0, top: 0, right: 1, bottom: 1 };
var outputDir = CONFIG.OUTPUT_DIR || "";
var logPath = "";

/* ------------------------------ 配置与基础工具 ------------------------------ */
function normalize(value) {
  return Core.normalize(value);
}

function matchKeyword(value, candidates, synonymMap) {
  return Core.matchKeyword(value, candidates, synonymMap);
}

function nowStamp() {
  var d = new Date();
  function pad(n) { return n < 10 ? "0" + n : String(n); }
  return d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate()) + "_" +
    pad(d.getHours()) + pad(d.getMinutes()) + pad(d.getSeconds());
}

function log(message) {
  var line = "[" + new Date().toISOString() + "] " + String(message);
  console.log(line);
  try {
    if (outputDir) files.ensureDir(outputDir);
    if (logPath) files.append(logPath, line + "\n");
  } catch (e) {
    console.log("日志文件写入失败：" + e);
  }
}

function notify(message) {
  try { toastLog(String(message)); } catch (e) { log("通知：" + message); }
}

function safeRecycle(img) {
  try {
    if (img && typeof img.recycle === "function") img.recycle();
  } catch (e) {}
}

function imageWidth(img) {
  try { return Number(img.getWidth()); } catch (e) { return Number(device.width); }
}

function imageHeight(img) {
  try { return Number(img.getHeight()); } catch (e) { return Number(device.height); }
}

/* getRegion：将比例区域转换为当前截图像素区域。 */
function getRegion(img, ratioRegion) {
  var w = imageWidth(img);
  var h = imageHeight(img);
  var left = Math.max(0, Math.min(w - 1, Math.round(ratioRegion.left * w)));
  var top = Math.max(0, Math.min(h - 1, Math.round(ratioRegion.top * h)));
  var right = Math.max(left + 1, Math.min(w, Math.round(ratioRegion.right * w)));
  var bottom = Math.max(top + 1, Math.min(h, Math.round(ratioRegion.bottom * h)));
  return {
    x: left,
    y: top,
    w: right - left,
    h: bottom - top,
    left: left,
    top: top,
    right: right,
    bottom: bottom,
    centerX: Math.round((left + right) / 2),
    centerY: Math.round((top + bottom) / 2)
  };
}

function captureScreenSafe() {
  var img = images.captureScreen();
  if (!img) throw new Error("captureScreen() 没有返回截图");
  return img;
}

function saveDebugScreenshot(img, label) {
  try {
    var dir = outputDir + "/debug";
    files.ensureDir(dir);
    var path = dir + "/" + label + "_" + nowStamp() + ".jpg";
    images.save(img, path, "jpg", 92);
    log("已保存调试截图：" + path);
    return path;
  } catch (e) {
    log("截图保存失败：" + e);
    return "";
  }
}

function pause(reason, img) {
  if (runtime.state === STATES.PAUSE || runtime.state === STATES.STOP) return;
  runtime.pauseReason = String(reason || "未分类异常");
  runtime.state = STATES.PAUSE;
  log("STATE_PAUSE：" + runtime.pauseReason);
  if (img) saveDebugScreenshot(img, "PAUSE");
  notify("装备筛选已安全暂停：" + runtime.pauseReason);
}

function stop(reason) {
  if (runtime.state === STATES.STOP) return;
  runtime.stopReason = String(reason || "达到停止条件");
  runtime.state = STATES.STOP;
  log("STATE_STOP：" + runtime.stopReason);
}

function badOcr(reason, img) {
  runtime.ocrBadStreak++;
  runtime.lastOcrError = String(reason || "OCR为空或置信度过低");
  log("OCR异常连续计数 " + runtime.ocrBadStreak + "/" + CONFIG.OCR_MAX_EMPTY_STREAK + "：" + runtime.lastOcrError);
  if (runtime.ocrBadStreak >= CONFIG.OCR_MAX_EMPTY_STREAK) {
    pause("OCR连续" + CONFIG.OCR_MAX_EMPTY_STREAK + "次为空或置信度不足：" + runtime.lastOcrError, img);
  }
}

function structuralOcrFailure(reason, img) {
  runtime.structuralBadStreak++;
  log("OCR结构解析异常连续计数 " + runtime.structuralBadStreak + "/" + CONFIG.OCR_MAX_EMPTY_STREAK + "：" + reason);
  if (runtime.structuralBadStreak >= CONFIG.OCR_MAX_EMPTY_STREAK) {
    pause("OCR有文字但无法可靠解析：" + reason, img);
  }
}

function structuralOcrSuccess() {
  runtime.structuralBadStreak = 0;
}

function validateConfig() {
  if (CONFIG.CORE_AFFIX_POOL.length !== 14) throw new Error("CORE_AFFIX_POOL 必须保留 14 个词条");
  if (CONFIG.SUB_STATS.length !== 14) throw new Error("SUB_STATS 必须保留 14 个词条");
  if (CONFIG.CORE_AFFIX_POOL.indexOf(CONFIG.TARGET_CORE_AFFIX) < 0) {
    throw new Error("TARGET_CORE_AFFIX 必须是 CORE_AFFIX_POOL 中的一个标准词条");
  }
  if (!CONFIG.REQUIRED_SUB_STATS || !CONFIG.REQUIRED_SUB_STATS.length) {
    throw new Error("REQUIRED_SUB_STATS 不能为空；至少配置一个目标副词条后才能开始挂机");
  }
  for (var i = 0; i < CONFIG.REQUIRED_SUB_STATS.length; i++) {
    if (SUB_STATS.indexOf(CONFIG.REQUIRED_SUB_STATS[i]) < 0) {
      throw new Error("未知目标副词条：" + CONFIG.REQUIRED_SUB_STATS[i]);
    }
  }
  if (CONFIG.BAG_GRID.rows * CONFIG.BAG_GRID.columns > CONFIG.MAX_BAG_CELLS) {
    throw new Error("背包格子数量超过 MAX_BAG_CELLS");
  }
  if (CONFIG.OCR_MODE !== "mlkit" && CONFIG.OCR_MODE !== "paddle" && CONFIG.OCR_MODE !== "rapid") {
    throw new Error("OCR_MODE 只能是 mlkit / paddle / rapid");
  }
}

/* ------------------------------ OCR 识别工具 ------------------------------ */
function extractOcrText(result) {
  if (result == null) return "";
  if (typeof result === "string") return result;
  if (result.label != null) return String(result.label);
  if (result.text != null) return String(result.text);
  if (result.value != null) return String(result.value);
  if (result.content != null) return String(result.content);
  return "";
}

function extractConfidence(result) {
  if (result == null) return 0;
  var value = result.confidence;
  if (value == null) value = result.score;
  if (value == null) value = result.probability;
  if (value == null) return (typeof result === "string") ? 1 : 0.9;
  value = Number(value);
  if (value > 1 && value <= 100) value = value / 100;
  return isNaN(value) ? 0 : value;
}

function extractBounds(result, fallbackIndex) {
  var b = result && (result.bounds || result.rect || result.box || result.boundingBox);
  if (!b) return { left: 0, top: fallbackIndex * 20, right: 1, bottom: fallbackIndex * 20 + 18 };
  if (Array.isArray(b) && b.length >= 4) {
    return { left: Number(b[0]), top: Number(b[1]), right: Number(b[2]), bottom: Number(b[3]) };
  }
  var left = b.left;
  var top = b.top;
  var right = b.right;
  var bottom = b.bottom;
  if (left == null) left = b.x;
  if (top == null) top = b.y;
  if (right == null && b.width != null) right = Number(left || 0) + Number(b.width);
  if (bottom == null && b.height != null) bottom = Number(top || 0) + Number(b.height);
  if (left == null || top == null || right == null || bottom == null) {
    return { left: 0, top: fallbackIndex * 20, right: 1, bottom: fallbackIndex * 20 + 18 };
  }
  return { left: Number(left), top: Number(top), right: Number(right), bottom: Number(bottom) };
}

function normalizeOcrEntries(raw) {
  var arr = [];
  if (raw == null) return arr;
  if (!Array.isArray(raw)) {
    try { raw = Array.prototype.slice.call(raw); } catch (e) { raw = [raw]; }
  }
  for (var i = 0; i < raw.length; i++) {
    var textValue = extractOcrText(raw[i]);
    if (!textValue) continue;
    arr.push({
      text: textValue,
      confidence: extractConfidence(raw[i]),
      bounds: extractBounds(raw[i], i),
      raw: raw[i]
    });
  }
  return arr;
}

/* ocrRegion：固定区域截图裁剪，再用 ocr.detect() 读取文字、置信度和边界框。 */
function ocrRegion(img, ratioRegion, options) {
  options = options || {};
  var required = options.required !== false;
  var rect = getRegion(img, ratioRegion);
  var crop = null;
  var entries = [];
  try {
    crop = images.clip(img, rect.x, rect.y, rect.w, rect.h);
    var raw = ocr.detect(crop);
    entries = normalizeOcrEntries(raw);
  } catch (e) {
    if (required) badOcr("OCR引擎异常：" + e, img);
    return { ok: false, rect: rect, entries: [], text: "", confidence: 0, error: String(e) };
  } finally {
    safeRecycle(crop);
  }

  var textParts = [];
  var confidenceSum = 0;
  var highCount = 0;
  for (var i = 0; i < entries.length; i++) {
    textParts.push(entries[i].text);
    confidenceSum += entries[i].confidence;
    if (entries[i].confidence >= CONFIG.OCR_MIN_CONFIDENCE) highCount++;
  }
  var avg = entries.length ? confidenceSum / entries.length : 0;
  var valid = entries.length > 0 && highCount > 0 && avg >= CONFIG.OCR_MIN_CONFIDENCE;
  var result = {
    ok: valid,
    rect: rect,
    entries: entries,
    text: textParts.join(" "),
    confidence: avg,
    error: ""
  };

  if (required && !valid) {
    badOcr(entries.length ? "置信度不足，均值=" + avg.toFixed(2) : "识别结果为空", img);
  } else if (valid) {
    runtime.ocrBadStreak = 0;
  }
  return result;
}

function groupOcrRows(ocrData) {
  if (!ocrData || !ocrData.entries) return [];
  var items = ocrData.entries.slice();
  items.sort(function (a, b) {
    var ay = (a.bounds.top + a.bounds.bottom) / 2;
    var by = (b.bounds.top + b.bounds.bottom) / 2;
    if (Math.abs(ay - by) > 2) return ay - by;
    return a.bounds.left - b.bounds.left;
  });
  var threshold = Math.max(9, Math.round(ocrData.rect.h * 0.035));
  var rows = [];
  items.forEach(function (item) {
    var cy = (item.bounds.top + item.bounds.bottom) / 2;
    var matched = null;
    for (var i = 0; i < rows.length; i++) {
      if (Math.abs(rows[i].centerY - cy) <= threshold) {
        matched = rows[i];
        break;
      }
    }
    if (!matched) {
      matched = { centerY: cy, entries: [], text: "", confidence: 0 };
      rows.push(matched);
    }
    matched.entries.push(item);
  });
  rows.forEach(function (row) {
    row.entries.sort(function (a, b) { return a.bounds.left - b.bounds.left; });
    row.text = row.entries.map(function (e) { return e.text; }).join(" ");
    row.confidence = row.entries.reduce(function (sum, e) { return sum + e.confidence; }, 0) / row.entries.length;
    row.entries.forEach(function (entry) {
      if (entry.bounds.left < row.left || row.left == null) row.left = entry.bounds.left;
      if (entry.bounds.right > row.right || row.right == null) row.right = entry.bounds.right;
    });
  });
  rows.sort(function (a, b) { return a.centerY - b.centerY; });
  return rows;
}

function parseStatRows(ocrData) {
  var rows = groupOcrRows(ocrData);
  var parsed = [];
  rows.forEach(function (row) {
    var stat = Core.matchStatRow(row.text, SUB_STATS, Core.STAT_SYNONYMS);
    if (stat) {
      parsed.push({
        stat: stat,
        raw: row.text,
        centerY: row.centerY,
        confidence: row.confidence,
        left: row.left,
        right: row.right
      });
    }
  });
  return parsed;
}

function getMainAndSubStats(ocrData) {
  var rows = parseStatRows(ocrData);
  if (rows.length < 2) return { ok: false, rows: rows, mainStat: null, subStats: [] };
  return {
    ok: true,
    rows: rows,
    mainStat: rows[0].stat,
    subStats: rows.slice(1).map(function (row) { return row.stat; })
  };
}

function getPartByMainStat(mainStat, slot) {
  var inferred = Core.inferPartFromMain(mainStat, CONFIG.EQUIPMENT_MAIN_STATS);
  var manualKey = slot ? (slot.row + "," + slot.col) : "";
  var manual = manualKey && CONFIG.MANUAL_PART_BY_CELL[manualKey] ? CONFIG.MANUAL_PART_BY_CELL[manualKey] : null;
  if (manual && PARTS.indexOf(manual) < 0) return null;
  if (manual && inferred && manual !== inferred) return null;
  return manual || inferred;
}

function detectPartFromTitle(ocrData) {
  if (!ocrData || !ocrData.text) return null;
  return matchKeyword(ocrData.text, PARTS, Core.PART_SYNONYMS);
}

/* ------------------------------ 像素 / 模板辅助 ------------------------------ */
function colorRgb(color) {
  var c = Number(color) >>> 0;
  return {
    r: (c >> 16) & 255,
    g: (c >> 8) & 255,
    b: c & 255
  };
}

function hasGearIcon(img, cellRect) {
  if (!CONFIG.BAG_REQUIRE_GEAR_ICON) return true;
  var count = 0;
  var step = Math.max(2, CONFIG.BAG_COLOR_SAMPLE_STEP || 3);
  for (var y = cellRect.y + Math.round(cellRect.h * 0.12); y < cellRect.y + cellRect.h * 0.78; y += step) {
    for (var x = cellRect.x + Math.round(cellRect.w * 0.12); x < cellRect.x + cellRect.w * 0.88; x += step) {
      var rgb;
      try { rgb = colorRgb(images.pixel(img, x, y)); } catch (e) { return true; }
      var gold = rgb.r > 125 && rgb.g > 95 && rgb.r > rgb.b * 1.22 && rgb.g > rgb.b * 1.12;
      var blue = rgb.b > 105 && rgb.b > rgb.r * 1.10 && rgb.g > 65 && rgb.r > 40;
      if (gold || blue) count++;
    }
  }
  return count >= CONFIG.BAG_MIN_GEAR_COLOR_PIXELS;
}

function countWhitePixels(img, rect, settings) {
  var count = 0;
  var step = Math.max(1, settings.sampleStep || 2);
  for (var y = rect.y; y < rect.y + rect.h; y += step) {
    for (var x = rect.x; x < rect.x + rect.w; x += step) {
      var rgb;
      try { rgb = colorRgb(images.pixel(img, x, y)); } catch (e) { return -1; }
      var maxC = Math.max(rgb.r, rgb.g, rgb.b);
      var minC = Math.min(rgb.r, rgb.g, rgb.b);
      if (minC >= settings.brightnessMin && (maxC - minC) <= settings.channelDeltaMax) count++;
    }
  }
  return count;
}

function isLockedByColor(img, cellRect) {
  if (!CONFIG.LOCK_DETECT.enabled) return false;
  var s = CONFIG.LOCK_DETECT;
  var sub = {
    x: Math.round(cellRect.x + cellRect.w * s.roiLeft),
    y: Math.round(cellRect.y + cellRect.h * s.roiTop),
    w: Math.max(1, Math.round(cellRect.w * (s.roiRight - s.roiLeft))),
    h: Math.max(1, Math.round(cellRect.h * (s.roiBottom - s.roiTop)))
  };
  var count = countWhitePixels(img, sub, s);
  if (count < 0) return false;
  return count >= s.minWhitePixels;
}

function countGreenPixels(img, rect) {
  var count = 0;
  for (var y = rect.y; y < rect.y + rect.h; y += 2) {
    for (var x = rect.x; x < rect.x + rect.w; x += 2) {
      var rgb;
      try { rgb = colorRgb(images.pixel(img, x, y)); } catch (e) { return -1; }
      if (rgb.g >= 90 && rgb.g > rgb.r * 1.22 && rgb.g > rgb.b * 1.12) count++;
    }
  }
  return count;
}

function findResetIconPoint(img) {
  /* 仍以用户给出的 C 区作为定位锚点；按附图将垂直搜索向下扩展，
   * 避免 C 区高度略偏时点击到装备标题或空白。只有命中绿色刷新图标才返回坐标。 */
  var search = getRegion(img, CONFIG.REGIONS.RESET_ICON_SEARCH || CONFIG.REGIONS.C_RESET);
  var count = 0;
  var minX = search.right, minY = search.bottom, maxX = search.left, maxY = search.top;
  for (var y = search.y; y < search.y + search.h; y += 2) {
    for (var x = search.x; x < search.x + search.w; x += 2) {
      var rgb;
      try { rgb = colorRgb(images.pixel(img, x, y)); } catch (e) { return null; }
      if (rgb.g >= 90 && rgb.g > rgb.r * 1.22 && rgb.g > rgb.b * 1.12) {
        count++;
        if (x < minX) minX = x;
        if (x > maxX) maxX = x;
        if (y < minY) minY = y;
        if (y > maxY) maxY = y;
      }
    }
  }
  if (count < 10) return null;
  return {
    x: Math.round((minX + maxX) / 2),
    y: Math.round((minY + maxY) / 2),
    pixels: count,
    bounds: { left: minX, top: minY, right: maxX, bottom: maxY }
  };
}

function isResetButtonReady(img) {
  runtime.resetButtonPoint = findResetIconPoint(img);
  return !!runtime.resetButtonPoint;
}

/* ------------------------------ 无障碍手势注入 ------------------------------ */
function clickByGesture(x, y) {
  var px = Number(x);
  var py = Number(y);
  if (!isFinite(px) || !isFinite(py)) throw new Error("clickByGesture 收到无效坐标");
  if (typeof gesture !== "function") throw new Error("当前运行环境没有 gesture() 无障碍手势接口");
  var w = Number(device.width);
  var h = Number(device.height);
  if (px < 0 || py < 0 || px >= w || py >= h) throw new Error("点击坐标越界：" + px + "," + py);
  var wait = CONFIG.CLICK_DEBOUNCE_MS - (Date.now() - runtime.lastGestureAt);
  if (wait > 0) sleep(wait);
  var ix = Math.round(px);
  var iy = Math.round(py);
  /* 两点相距 1px 的短路径，使用 Android 无障碍 gesture 注入轻触。 */
  var sent = gesture(80, [ix, iy], [Math.min(w - 1, ix + 1), iy]);
  runtime.lastGestureAt = Date.now();
  if (sent === false) throw new Error("无障碍 gesture 注入返回失败");
  sleep(180);
  return true;
}

function clickRegionCenter(img, ratioRegion) {
  var r = getRegion(img, ratioRegion);
  return clickByGesture(r.centerX, r.centerY);
}

function findActionPoint(ocrData, label) {
  var target = normalize(label);
  if (!ocrData || !ocrData.entries) return null;
  var best = null;
  ocrData.entries.forEach(function (entry) {
    if (normalize(entry.text).indexOf(target) >= 0) {
      var x = Math.round(ocrData.rect.x + (entry.bounds.left + entry.bounds.right) / 2);
      var y = Math.round(ocrData.rect.y + (entry.bounds.top + entry.bounds.bottom) / 2);
      if (!best || entry.confidence > best.confidence) {
        best = { x: x, y: y, confidence: entry.confidence, text: entry.text };
      }
    }
  });
  return best;
}

function fullScreenOcr(img, required) {
  var data = ocrRegion(img, FULL_SCREEN, { required: required !== false });
  runtime.lastFullOcr = data;
  return data;
}

function clickActionFromOcr(img, label, fallbackRegion) {
  var full = fullScreenOcr(img, true);
  if (!full.ok || runtime.state === STATES.PAUSE) return false;
  var point = findActionPoint(full, label);
  if (point) {
    log("OCR定位按钮「" + label + "」：" + point.x + "," + point.y + "，置信度=" + point.confidence.toFixed(2));
    clickByGesture(point.x, point.y);
    return true;
  }
  if (CONFIG.ALLOW_FIXED_BUTTON_FALLBACK && fallbackRegion) {
    log("OCR未定位到「" + label + "」，使用已启用的固定比例坐标回退");
    clickRegionCenter(img, fallbackRegion);
    return true;
  }
  pause("全屏 OCR 未找到按钮文字「" + label + "」，拒绝使用不确定坐标", img);
  return false;
}

/* ------------------------------ 背包扫描 ------------------------------ */
function getBagCellRegion(row, col) {
  var bag = CONFIG.REGIONS.D_BAG;
  var cellW = (bag.right - bag.left) / CONFIG.BAG_GRID.columns;
  var cellH = (bag.bottom - bag.top) / CONFIG.BAG_GRID.rows;
  var inset = CONFIG.BAG_GRID.insetRatio || 0;
  return {
    left: bag.left + col * cellW + cellW * inset,
    top: bag.top + row * cellH + cellH * inset,
    right: bag.left + (col + 1) * cellW - cellW * inset,
    bottom: bag.top + (row + 1) * cellH - cellH * inset
  };
}

function getBagCellPixelRect(img, row, col) {
  return getRegion(img, getBagCellRegion(row, col));
}

function skipCell(reason, row, col) {
  log("跳过背包格 " + row + "," + col + "：" + reason);
  runtime.visitedCells[row + "," + col] = reason;
  runtime.bagCursor++;
}

function scanNextBagCell() {
  var img = captureScreenSafe();
  try {
    var width = imageWidth(img);
    var height = imageHeight(img);
    if (width < height * 1.15) {
      pause("当前截图不是预期的横屏布局；请将游戏切换为横屏后重新运行", img);
      return;
    }

    var total = Math.min(CONFIG.MAX_BAG_CELLS, CONFIG.BAG_GRID.rows * CONFIG.BAG_GRID.columns);
    while (runtime.bagCursor < total && runtime.state === STATES.SCAN_BAG) {
      var row = Math.floor(runtime.bagCursor / CONFIG.BAG_GRID.columns);
      var col = runtime.bagCursor % CONFIG.BAG_GRID.columns;
      var key = row + "," + col;
      if (runtime.visitedCells[key]) {
        runtime.bagCursor++;
        continue;
      }

      var cellRect = getBagCellPixelRect(img, row, col);
      if (!hasGearIcon(img, cellRect)) {
        skipCell("格子内未检测到装备图标（空格）", row, col);
        continue;
      }
      if (isLockedByColor(img, cellRect)) {
        skipCell("检测到右上角白色锁图标", row, col);
        continue;
      }

      var levelOcr = ocrRegion(img, getBagCellRegion(row, col), { required: true });
      if (!levelOcr.ok || runtime.state === STATES.PAUSE) return;
      var combined = levelOcr.text;
      if (normalize(combined).indexOf("锁") >= 0) {
        skipCell("OCR识别到锁定标记", row, col);
        continue;
      }
      var level = Core.parseLevel(combined);
      if (level == null) {
        structuralOcrFailure("背包格 " + key + " OCR 未识别到等级数字", img);
        if (runtime.state !== STATES.PAUSE) sleep(CONFIG.OCR_RETRY_DELAY_MS);
        return;
      }
      structuralOcrSuccess();
      if (CONFIG.LEVEL_ALLOWED.indexOf(level) < 0) {
        skipCell("等级" + level + "不允许重置（只允许等级1）", row, col);
        continue;
      }

      runtime.currentSlot = {
        row: row,
        col: col,
        index: runtime.bagCursor,
        x: cellRect.centerX,
        y: cellRect.centerY
      };
      runtime.currentRerolls = 0;
      runtime.currentItem = null;
      runtime.compareSnapshot = null;
      runtime.rerollLock = false;
      log("发现未锁定等级1装备：背包格 " + key + "，准备打开详情");
      clickByGesture(cellRect.centerX, cellRect.centerY);
      runtime.state = STATES.READ_DETAIL;
      return;
    }

    if (runtime.bagCursor >= total) stop("背包区域已扫描完毕，共检查 " + total + " 格");
  } finally {
    safeRecycle(img);
  }
}

/* ------------------------------ 详情读取与冲突判定 ------------------------------ */
function readCurrentDetail() {
  sleep(550);
  var img = captureScreenSafe();
  try {
    var statOcr = ocrRegion(img, CONFIG.REGIONS.A_STATS, { required: true });
    if (!statOcr.ok || runtime.state === STATES.PAUSE) return;
    var parsed = getMainAndSubStats(statOcr);
    if (!parsed.ok) {
      structuralOcrFailure("左侧属性区识别到的有效词条不足 2 行", img);
      return;
    }
    structuralOcrSuccess();

    var part = getPartByMainStat(parsed.mainStat, runtime.currentSlot);
    var immediateTargets = [CONFIG.TARGET_CORE_AFFIX].concat(CONFIG.REQUIRED_SUB_STATS || []);
    var immediateMainConflict = immediateTargets.indexOf(parsed.mainStat) >= 0;
    if ((!part || PARTS.indexOf(part) < 0) && !immediateMainConflict) {
      pause("无法根据主词条确定装备部位：" + parsed.mainStat, img);
      return;
    }
    if (part) {
      var allowedMain = CONFIG.EQUIPMENT_MAIN_STATS[part] || [];
      if (allowedMain.indexOf(parsed.mainStat) < 0) {
        pause("部位与主词条词典不一致：部位=" + part + "，主词条=" + parsed.mainStat, img);
        return;
      }
    }

    runtime.currentItem = {
      slot: runtime.currentSlot,
      part: part || null,
      mainStat: parsed.mainStat,
      subStats: parsed.subStats,
      statRows: parsed.rows,
      statsText: statOcr.text,
      setName: null,
      stage: "original"
    };
    log("详情识别：部位=" + (part || "未归类（主词条命中目标，直接执行冲突判定）") + "；主词条=" + parsed.mainStat + "；副词条=" + parsed.subStats.join("、"));
    runtime.state = STATES.JUDGE_CONFLICT;
  } finally {
    safeRecycle(img);
  }
}

function judgeMainStatConflict() {
  var item = runtime.currentItem;
  if (!item || !item.mainStat) {
    pause("当前装备缺少可靠主词条，不能执行冲突判定");
    return;
  }
  var targets = [CONFIG.TARGET_CORE_AFFIX].concat(CONFIG.REQUIRED_SUB_STATS || []);
  var collisions = targets.filter(function (stat) { return stat === item.mainStat; });
  if (collisions.length) {
    item.junkReason = "主副词条冲突：" + collisions.join("、") + " 已占用主词条位置";
    log("STATE_JUDGE_CONFLICT：" + item.junkReason + "；跳过套装 OCR，直接重置");
    runtime.state = STATES.CLICK_RESET;
    return;
  }
  log("STATE_JUDGE_CONFLICT：主副词条无冲突，部位=" + item.part + "，继续检查套装及副词条");
  runtime.state = STATES.JUDGE_RULES;
}

function judgeCurrentRules() {
  var img = captureScreenSafe();
  try {
    var setOcr = ocrRegion(img, CONFIG.REGIONS.B_SET_NAME, { required: true });
    if (!setOcr.ok || runtime.state === STATES.PAUSE) return;
    var setName = Core.findSet(setOcr.text, CONFIG.GOLD_SETS);
    if (!setName) {
      pause("套装名称无法在 GOLD_SETS 中确认：" + setOcr.text, img);
      return;
    }
    runtime.currentItem.setName = setName;

    if (CONFIG.REQUIRE_GOLD_SET && CONFIG.GOLD_SETS.indexOf(setName) < 0) {
      runtime.currentItem.junkReason = "套装不在金色套装词典中：" + setName;
      runtime.state = STATES.CLICK_RESET;
      log(runtime.currentItem.junkReason);
      return;
    }

    var evaluated = Core.evaluateAffixes(runtime.currentItem, CONFIG);
    if (evaluated.ok) {
      runtime.currentItem.junkReason = "";
      log("当前装备已满足极品条件，无需消耗硬币：" + setName + " / " + runtime.currentItem.mainStat + " / " + runtime.currentItem.subStats.join("、"));
      runtime.successItems.push(makeRecord(runtime.currentItem, "原装备已达标"));
      runtime.state = STATES.NEXT_ITEM;
      return;
    }

    runtime.currentItem.junkReason = evaluated.reason;
    log("当前装备判定为废品：" + evaluated.reason);
    runtime.state = STATES.CLICK_RESET;
  } finally {
    safeRecycle(img);
  }
}

/* ------------------------------ 重置 / 冷却 / 对比 ------------------------------ */
function clickInitialReset() {
  if (!runtime.currentItem) {
    pause("重置阶段没有当前装备数据");
    return;
  }
  if (runtime.totalRerolls >= CONFIG.MAX_TOTAL_REROLLS) {
    stop("达到整次任务最大重掷次数：" + CONFIG.MAX_TOTAL_REROLLS);
    return;
  }
  if (runtime.currentRerolls >= CONFIG.MAX_REROLLS_PER_ITEM) {
    stop("当前装备已达到单件最大重掷次数；为避免弹窗未确认时误扫背包，脚本停止，当前弹窗留待人工处理");
    return;
  }

  var img = captureScreenSafe();
  try {
    if (!isResetButtonReady(img)) {
      pause("区域 C 未检测到绿色刷新按钮；请确认仍处于装备详情界面并校准坐标", img);
      return;
    }
    var resetPoint = runtime.resetButtonPoint;
    if (!resetPoint) {
      pause("绿色刷新图标定位结果丢失；拒绝按固定坐标盲点", img);
      return;
    }
    log("颜色识别定位刷新按钮 C：" + resetPoint.x + "," + resetPoint.y + "；绿色采样=" + resetPoint.pixels);
    clickByGesture(resetPoint.x, resetPoint.y);
    runtime.lastResetAt = Date.now();
    runtime.rerollLock = true;
    runtime.state = STATES.WAIT_RESET_COOLDOWN;
  } finally {
    safeRecycle(img);
  }
}

function hasCompareActions(fullOcr) {
  var reroll = findActionPoint(fullOcr, "重掷") || findActionPoint(fullOcr, "重擲");
  var cont = findActionPoint(fullOcr, "继续") || findActionPoint(fullOcr, "繼續");
  return { ok: !!(reroll && cont), reroll: reroll, cont: cont };
}

function waitForComparePopup() {
  var start = Date.now();
  var lastImage = null;
  while (Date.now() - start < CONFIG.POPUP_TIMEOUT_MS && runtime.state === STATES.WAIT_RESET_COOLDOWN) {
    var img = captureScreenSafe();
    if (lastImage) safeRecycle(lastImage);
    lastImage = img;
    var full = fullScreenOcr(img, true);
    if (runtime.state === STATES.PAUSE) break;
    var actions = hasCompareActions(full);
    var cooldownDone = Date.now() - runtime.lastResetAt >= CONFIG.RESET_COOLDOWN_MS;
    if (actions.ok && cooldownDone) {
      runtime.rerollLock = false;
      log("已检测到重掷对比界面；按钮 OCR 定位成功，转入新词条判定");
      runtime.state = STATES.JUDGE_RESULT;
      break;
    }
    sleep(CONFIG.POLL_INTERVAL_MS);
  }
  if (runtime.state === STATES.WAIT_RESET_COOLDOWN) {
    pause("点击刷新后未在规定时间内识别到完整的「重掷 / 继续」对比界面", lastImage);
  }
  safeRecycle(lastImage);
}

function makeResultSignature(parsed, text) {
  return (parsed && parsed.rows ? parsed.rows.map(function (r) { return r.stat; }).join("|") : "") + "#" + normalize(text || "");
}

function readCompareSnapshot(img, required) {
  var data = ocrRegion(img, CONFIG.REGIONS.E_COMPARE, { required: required !== false });
  if (!data.ok || runtime.state === STATES.PAUSE) return { ok: false, reason: "对比属性区域 OCR 失败" };
  var parsed = getMainAndSubStats(data);
  if (!parsed.ok) {
    if (required !== false) structuralOcrFailure("对比区域中有效新词条不足 2 行", img);
    return { ok: false, reason: "新词条行数不足", data: data };
  }
  structuralOcrSuccess();
  var part = Core.inferPartFromMain(parsed.mainStat, CONFIG.EQUIPMENT_MAIN_STATS);
  if (!part) {
    if (required !== false) structuralOcrFailure("新装备主词条不属于已知主词条池：" + parsed.mainStat, img);
    return { ok: false, reason: "新装备主词条无法归类", data: data, parsed: parsed };
  }
  var result = {
    ok: true,
    part: part,
    mainStat: parsed.mainStat,
    subStats: parsed.subStats,
    rows: parsed.rows,
    text: data.text,
    signature: makeResultSignature(parsed, data.text),
    rawOcr: data
  };
  result.evaluation = Core.evaluateAffixes(result, CONFIG);
  return result;
}

function judgeNewResult() {
  var img = captureScreenSafe();
  try {
    var full = fullScreenOcr(img, true);
    if (!full.ok || runtime.state === STATES.PAUSE) return;
    var actions = hasCompareActions(full);
    if (!actions.ok) {
      pause("当前界面缺少「重掷」或「继续」按钮，不能安全判断新装备", img);
      return;
    }
    var snapshot = readCompareSnapshot(img, true);
    if (!snapshot.ok || runtime.state === STATES.PAUSE) return;
    runtime.compareSnapshot = snapshot;

    log("新装备识别：部位=" + snapshot.part + "；主词条=" + snapshot.mainStat + "；副词条=" + snapshot.subStats.join("、"));
    if (snapshot.evaluation.ok) {
      log("新装备达到极品标准：" + snapshot.evaluation.reason);
      runtime.currentItem.newPart = snapshot.part;
      runtime.currentItem.newMainStat = snapshot.mainStat;
      runtime.currentItem.newSubStats = snapshot.subStats;
      runtime.currentItem.newSetName = runtime.currentItem.setName;
      runtime.currentItem.stage = "rerolled";
      runtime.state = STATES.CLICK_CONTINUE;
      return;
    }

    runtime.currentItem.junkReason = snapshot.evaluation.reason;
    log("新装备仍为废品：" + snapshot.evaluation.reason);
    if (runtime.totalRerolls >= CONFIG.MAX_TOTAL_REROLLS) {
      stop("达到整次任务最大重掷次数：" + CONFIG.MAX_TOTAL_REROLLS);
      return;
    }
    if (runtime.currentRerolls >= CONFIG.MAX_REROLLS_PER_ITEM) {
      stop("当前装备达到单件最大重掷次数；对比弹窗保留，脚本停止以待人工处理");
      return;
    }
    runtime.beforeRerollSignature = snapshot.signature;
    runtime.state = STATES.CLICK_REROLL;
  } finally {
    safeRecycle(img);
  }
}

function clickRerollButton() {
  if (runtime.rerollLock) {
    pause("重掷冷却锁仍处于锁定状态，拒绝二次点击");
    return;
  }
  if (runtime.totalRerolls >= CONFIG.MAX_TOTAL_REROLLS) {
    stop("达到整次任务最大重掷次数");
    return;
  }
  if (runtime.currentRerolls >= CONFIG.MAX_REROLLS_PER_ITEM) {
    stop("当前装备达到单件最大重掷次数；对比弹窗仍打开，脚本停止以待人工处理");
    return;
  }

  var img = captureScreenSafe();
  try {
    var full = fullScreenOcr(img, true);
    if (!full.ok || runtime.state === STATES.PAUSE) return;
    var actions = hasCompareActions(full);
    if (!actions.ok || !actions.reroll) {
      pause("点击重掷前未识别到可用的「重掷」按钮", img);
      return;
    }

    var coinBalance = readSilverCoinBalance(img);
    if (coinBalance == null) {
      pause("无法可靠读取银币余额，拒绝在余额未知时消耗硬币", img);
      return;
    }
    if (coinBalance === 0) {
      stop("检测到银币余额为 0，停止重掷");
      return;
    }
    runtime.coinBalanceBeforeReroll = coinBalance;

    var sinceReset = Date.now() - Math.max(runtime.lastResetAt, runtime.lastRerollAt);
    var remaining = CONFIG.REROLL_COOLDOWN_MS - sinceReset;
    if (remaining > 0) sleep(remaining);

    log("点击重掷按钮（单次消耗按游戏界面显示为 1 枚银币）");
    clickByGesture(actions.reroll.x, actions.reroll.y);
    runtime.lastRerollAt = Date.now();
    runtime.currentRerolls++;
    runtime.totalRerolls++;
    runtime.rerollLock = true;
    runtime.state = STATES.WAIT_REROLL_COOLDOWN;
  } finally {
    safeRecycle(img);
  }
}

function readSilverCoinBalance(img) {
  var data = ocrRegion(img, CONFIG.REGIONS.COIN_BALANCE, { required: false });
  if (!data || !data.ok || !data.text) return null;
  var matches = normalize(data.text).match(/\d{1,9}/g);
  if (!matches || !matches.length) return null;
  /* 余额区按用户截图包含第二行银币数字；ROI 只截取右上角第二行。 */
  var value = parseInt(matches[matches.length - 1], 10);
  return isNaN(value) ? null : value;
}

function waitForRerollResultChange() {
  var start = Date.now();
  var stableChangedCount = 0;
  var lastImage = null;
  while (Date.now() - start < CONFIG.RESULT_CHANGE_TIMEOUT_MS && runtime.state === STATES.WAIT_REROLL_COOLDOWN) {
    var img = captureScreenSafe();
    if (lastImage) safeRecycle(lastImage);
    lastImage = img;

    var cooldownDone = Date.now() - runtime.lastRerollAt >= CONFIG.REROLL_COOLDOWN_MS;
    var full = fullScreenOcr(img, true);
    if (runtime.state === STATES.PAUSE) break;
    var actions = hasCompareActions(full);
    if (actions.ok) {
      var snap = readCompareSnapshot(img, true);
      var coinNow = readSilverCoinBalance(img);
      var coinSpent = runtime.coinBalanceBeforeReroll != null && coinNow != null && coinNow < runtime.coinBalanceBeforeReroll;
      var resultChanged = snap && snap.ok && snap.signature !== runtime.beforeRerollSignature;
      if (snap && snap.ok && (resultChanged || coinSpent)) stableChangedCount++;
      else stableChangedCount = 0;
      if (cooldownDone && stableChangedCount >= 1) {
        runtime.compareSnapshot = snap;
        runtime.rerollLock = false;
        log("重掷结果已更新或已确认银币扣除，且冷却结束，允许进入下一轮判定");
        runtime.state = STATES.JUDGE_RESULT;
        break;
      }
    } else {
      stableChangedCount = 0;
    }
    sleep(CONFIG.POLL_INTERVAL_MS);
  }
  if (runtime.state === STATES.WAIT_REROLL_COOLDOWN) {
    pause("重掷后对比界面未在超时内更新；为防止连点，已锁住重掷按钮", lastImage);
  }
  safeRecycle(lastImage);
}

function clickContinueButton() {
  if (runtime.rerollLock) {
    pause("重掷冷却锁未释放，拒绝提前确认新装备");
    return;
  }
  var img = captureScreenSafe();
  try {
    var full = fullScreenOcr(img, true);
    if (!full.ok || runtime.state === STATES.PAUSE) return;
    var actions = hasCompareActions(full);
    if (!actions.ok || !actions.cont) {
      pause("新装备达标，但没有识别到「继续」确认按钮", img);
      return;
    }
    clickByGesture(actions.cont.x, actions.cont.y);
    runtime.state = STATES.WAIT_CONTINUE;
  } finally {
    safeRecycle(img);
  }
}

function waitForContinueClose() {
  var start = Date.now();
  var clearCount = 0;
  var lastImage = null;
  while (Date.now() - start < CONFIG.POPUP_TIMEOUT_MS && runtime.state === STATES.WAIT_CONTINUE) {
    var img = captureScreenSafe();
    if (lastImage) safeRecycle(lastImage);
    lastImage = img;
    var full = fullScreenOcr(img, true);
    if (runtime.state === STATES.PAUSE) break;
    var actions = hasCompareActions(full);
    if (!actions.ok) clearCount++;
    else clearCount = 0;
    if (clearCount >= 2) {
      log("「继续」已确认，对比弹窗关闭");
      if (runtime.currentItem) runtime.successItems.push(makeRecord(runtime.currentItem, "重掷后达标"));
      runtime.state = STATES.NEXT_ITEM;
      break;
    }
    sleep(CONFIG.POLL_INTERVAL_MS);
  }
  if (runtime.state === STATES.WAIT_CONTINUE) {
    pause("点击「继续」后，对比弹窗没有按预期关闭", lastImage);
  }
  safeRecycle(lastImage);
}

/* ------------------------------ 记录 / 下一件 / 状态机 ------------------------------ */
function makeRecord(item, status) {
  return {
    slot: item.slot ? (item.slot.row + "," + item.slot.col) : "?",
    originalPart: item.part || "?",
    setName: item.setName || "?",
    originalMainStat: item.mainStat || "?",
    originalSubStats: (item.subStats || []).join("、"),
    finalPart: item.newPart || item.part || "?",
    finalMainStat: item.newMainStat || item.mainStat || "?",
    finalSubStats: (item.newSubStats || item.subStats || []).join("、"),
    rerolls: runtime.currentRerolls,
    status: status,
    recordedAt: new Date().toISOString()
  };
}

function persistSuccessRecords() {
  try {
    files.ensureDir(outputDir);
    var path = outputDir + "/treasures.json";
    files.write(path, JSON.stringify(runtime.successItems, null, 2));
    log("极品装备记录已写入：" + path);
  } catch (e) {
    log("极品装备记录写入失败：" + e);
  }
}

function nextItem() {
  if (runtime.currentSlot) {
    runtime.visitedCells[runtime.currentSlot.row + "," + runtime.currentSlot.col] = "已处理";
    runtime.bagCursor = runtime.currentSlot.index + 1;
  }
  runtime.currentSlot = null;
  runtime.currentItem = null;
  runtime.currentRerolls = 0;
  runtime.compareSnapshot = null;
  runtime.rerollLock = false;
  runtime.coinBalanceBeforeReroll = null;
  runtime.state = STATES.SCAN_BAG;
}

function runStateMachine() {
  log("启动显式状态机；当前核心词条=" + CONFIG.TARGET_CORE_AFFIX + "；目标副词条=" + CONFIG.REQUIRED_SUB_STATS.join("、"));
  notify("装备筛选脚本已启动。建议首次运行先观察前 1-2 件装备。");

  /* 显式状态机：只在非 STOP / PAUSE 状态推进，不存在 while(true) 盲点。 */
  while (runtime.state !== STATES.STOP && runtime.state !== STATES.PAUSE) {
    log("状态切换执行：" + runtime.state);
    try {
      switch (runtime.state) {
        case STATES.SCAN_BAG:
          scanNextBagCell();
          break;

        case STATES.READ_DETAIL:
          readCurrentDetail();
          break;

        case STATES.JUDGE_CONFLICT:
          judgeMainStatConflict();
          break;

        case STATES.JUDGE_RULES:
          judgeCurrentRules();
          break;

        case STATES.CLICK_RESET:
          clickInitialReset();
          break;

        case STATES.WAIT_RESET_COOLDOWN:
          waitForComparePopup();
          break;

        case STATES.JUDGE_RESULT:
          judgeNewResult();
          break;

        case STATES.CLICK_REROLL:
          clickRerollButton();
          break;

        case STATES.WAIT_REROLL_COOLDOWN:
          waitForRerollResultChange();
          break;

        case STATES.CLICK_CONTINUE:
          clickContinueButton();
          break;

        case STATES.WAIT_CONTINUE:
          waitForContinueClose();
          break;

        case STATES.NEXT_ITEM:
          nextItem();
          break;

        default:
          pause("遇到未定义状态：" + runtime.state);
          break;
      }
    } catch (e) {
      log("状态机异常：" + e + "\n" + (e && e.stack ? e.stack : ""));
      var errImage = null;
      try { errImage = captureScreenSafe(); } catch (captureError) {}
      pause("状态机捕获到异常：" + e, errImage);
      safeRecycle(errImage);
    }
  }
}

function finish() {
  persistSuccessRecords();
  var summary = "完成。极品 " + runtime.successItems.length + " 件；重掷 " + runtime.totalRerolls + " 次。";
  if (runtime.state === STATES.PAUSE) summary = "已暂停：" + runtime.pauseReason + "。极品 " + runtime.successItems.length + " 件；重掷 " + runtime.totalRerolls + " 次。";
  if (runtime.state === STATES.STOP) summary = "已停止：" + runtime.stopReason + "。极品 " + runtime.successItems.length + " 件；重掷 " + runtime.totalRerolls + " 次。";
  log(summary);
  notify(summary);
}

/* ------------------------------ 初始化 ------------------------------ */
function resolveOutputDir() {
  if (CONFIG.OUTPUT_DIR) return CONFIG.OUTPUT_DIR;
  try {
    var external = context.getExternalFilesDir(null);
    if (external) return String(external.getAbsolutePath()) + "/Treasure";
  } catch (e) {
    log("无法读取应用专属外部目录，使用 Android app-specific 备用路径：" + e);
  }
  return "/sdcard/Android/data/com.kairnos.deadahead.gearfilter/files/Treasure";
}

function initialize() {
  validateConfig();
  outputDir = resolveOutputDir();
  logPath = outputDir + "/run.log";
  files.ensureDir(outputDir);
  files.ensureDir(outputDir + "/debug");

  log("日志与截图输出目录：" + outputDir);

  if (CONFIG.KEEP_SCREEN_ON && device.keepScreenOn) {
    try { device.keepScreenOn(60 * 60 * 1000); } catch (e) {}
  }

  /* 仅启用无障碍服务；不读取任何控件树或控件 ID。 */
  auto.waitFor();

  var captureGranted = images.requestScreenCapture();
  if (captureGranted === false) throw new Error("用户拒绝了截图权限");

  if (typeof ocr !== "function" || typeof ocr.detect !== "function") {
    throw new Error("当前 AutoJs6 环境缺少 ocr.detect；请使用兼容的 AutoJs6 版本和 OCR 引擎");
  }
  ocr.mode = CONFIG.OCR_MODE;

  var first = captureScreenSafe();
  try {
    if (imageWidth(first) < imageHeight(first) * 1.15) {
      throw new Error("游戏必须处于横屏界面；请旋转屏幕并重新运行");
    }
    /* 启动时预热 OCR 引擎；若 APK 未包含 Rapid OCR 模型或本地库，
     * 在任何游戏点击发生前就会初始化失败并暂停。 */
    var warmup = ocr.detect(first);
    if (warmup == null) throw new Error("Rapid OCR 引擎未返回结果");
    if (CONFIG.DEBUG_SAVE_EVERY_SCREEN) saveDebugScreenshot(first, "START");
    log("初始化成功；截图分辨率=" + imageWidth(first) + "x" + imageHeight(first) +
      "；OCR=" + CONFIG.OCR_MODE + "；预热检测框=" + warmup.length);
  } finally {
    safeRecycle(first);
  }
}

try {
  initialize();
  runStateMachine();
} catch (initError) {
  log("初始化失败：" + initError);
  pause("初始化失败：" + initError);
}
finish();
